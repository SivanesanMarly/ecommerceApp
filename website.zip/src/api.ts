import axios from 'axios';
import type {
  CatalogImportSummary,
  NotificationPayload,
  OrderDetail,
  OrderHistoryItem,
  Product,
  Session,
  Shop,
  Supplier,
  SupplyOrder,
} from './types';

const BASE_URL =
  import.meta.env.VITE_BACKEND_BASE_URL?.trim() ||
  'https://sivanesan8113test.pythonanywhere.com';
  // 'http://localhost:8000';

const http = axios.create({
  baseURL: BASE_URL,
  timeout: 12000,
});

function authHeader(token: string) {
  return { Authorization: `Bearer ${token}` };
}

export const api = {
  baseUrl: BASE_URL,

  async getShop() {
    const { data } = await http.get<Shop>('/api/shop');
    return data;
  },

  async getProducts() {
    const { data } = await http.get<Product[]>('/api/products');
    return data;
  },

  async login(identifier: string, password: string) {
    const { data } = await http.post<Session>('/api/auth/user/login', {
      identifier,
      password,
    });
    return data;
  },

  async adminLogin(payload: {
    email: string;
    phone: string;
    password: string;
    shop_name: string;
    shop_location: string;
  }) {
    const { data } = await http.post<Session>('/api/auth/admin/login', payload);
    return data;
  },

  async registerUser(payload: {
    username: string;
    email: string;
    country_code: string;
    phone: string;
    password: string;
  }) {
    await http.post('/api/auth/register/user', payload);
  },

  async checkout(token: string, cart: Record<string, number>) {
    const items = Object.entries(cart)
      .filter(([, qty]) => qty > 0)
      .map(([product_id, quantity]) => ({ product_id, quantity }));

    const { data } = await http.post(
      '/api/orders/checkout',
      { items },
      { headers: authHeader(token) },
    );
    return data;
  },

  async getOrderHistory(token: string) {
    const { data } = await http.get<OrderHistoryItem[]>('/api/orders/history', {
      headers: authHeader(token),
    });
    return data;
  },

  async getOrderDetail(token: string, orderId: string) {
    const { data } = await http.get<OrderDetail>(`/api/orders/${orderId}`, {
      headers: authHeader(token),
    });
    return data;
  },

  async confirmDelivered(token: string, orderId: string) {
    const { data } = await http.post<OrderDetail>(
      `/api/orders/${orderId}/confirm-delivered`,
      {},
      { headers: authHeader(token) },
    );
    return data;
  },

  async getAdminOrders(token: string) {
    const { data } = await http.get<OrderHistoryItem[]>('/api/admin/orders', {
      headers: authHeader(token),
    });
    return data;
  },

  async getAdminOrderDetail(token: string, orderId: string) {
    const { data } = await http.get<OrderDetail>(`/api/admin/orders/${orderId}`, {
      headers: authHeader(token),
    });
    return data;
  },

  async updateAdminOrderStatus(token: string, orderId: string, status: string) {
    const { data } = await http.post<OrderDetail>(
      `/api/admin/orders/${orderId}/status`,
      { status },
      { headers: authHeader(token) },
    );
    return data;
  },

  async updateShop(token: string, payload: {
    name: string;
    tagline: string;
    location: string;
    eta_minutes: number;
    is_open: boolean;
  }) {
    const { data } = await http.post<Shop>('/api/admin/shop/update', payload, {
      headers: authHeader(token),
    });
    return data;
  },

  async createAdminProduct(
    token: string,
    payload: {
      name: string;
      description: string;
      short_description?: string;
      category: string;
      subcategory?: string;
      brand?: string;
      slug?: string;
      currency?: string;
      tax_percent?: number;
      stock_status?: string;
      price: number;
      compare_at_price: number;
      rating: number;
      inventory: number;
      unit: string;
      unit_value: number;
      image?: File | null;
    },
  ) {
    const fd = new FormData();
    Object.entries(payload).forEach(([k, v]) => {
      if (v === undefined || v === null) return;
      if (k === 'image' && v instanceof File) {
        fd.append('image', v);
      } else {
        fd.append(k, String(v));
      }
    });
    const { data } = await http.post<Product>('/api/admin/products', fd, {
      headers: authHeader(token),
    });
    return data;
  },

  async deleteAdminProduct(token: string, productId: string) {
    await http.delete(`/api/admin/products/${productId}`, {
      headers: authHeader(token),
    });
  },

  async updateAdminProduct(
    token: string,
    productId: string,
    payload: {
      name: string;
      description: string;
      short_description?: string;
      category: string;
      subcategory?: string;
      brand?: string;
      slug?: string;
      currency?: string;
      tax_percent?: number;
      stock_status?: string;
      price: number;
      compare_at_price: number;
      rating: number;
      inventory: number;
      unit: string;
      unit_value: number;
      image?: File | null;
    },
  ) {
    const fd = new FormData();
    Object.entries(payload).forEach(([k, v]) => {
      if (v === undefined || v === null) return;
      if (k === 'image' && v instanceof File) {
        fd.append('image', v);
      } else {
        fd.append(k, String(v));
      }
    });
    const { data } = await http.put<Product>(`/api/admin/products/${productId}`, fd, {
      headers: authHeader(token),
    });
    return data;
  },

  async updateAdminProductDeal(
    token: string,
    productId: string,
    payload: {
      enabled: boolean;
      discount_percent?: number;
      starts_at?: string | null;
      ends_at?: string | null;
      priority?: number;
      badge?: string;
    },
  ) {
    const { data } = await http.post<Product>(`/api/admin/products/${productId}/deal`, payload, {
      headers: authHeader(token),
    });
    return data;
  },

  async getSuppliers(token: string) {
    const { data } = await http.get<Supplier[]>('/api/admin/suppliers', {
      headers: authHeader(token),
    });
    return data;
  },

  async createSupplier(
    token: string,
    payload: {
      username: string;
      email: string;
      country_code: string;
      phone: string;
      address: string;
      password: string;
    },
  ) {
    await http.post('/api/admin/suppliers', payload, {
      headers: authHeader(token),
    });
  },

  async getAdminSupplierProducts(token: string, supplierUserId?: string) {
    const query = supplierUserId
      ? `?supplier_user_id=${encodeURIComponent(supplierUserId)}`
      : '';
    const { data } = await http.get<Product[]>(`/api/admin/supplier-products${query}`, {
      headers: authHeader(token),
    });
    return data;
  },

  async createSupplyOrder(
    token: string,
    payload: {
      supplier_user_id: string;
      notes: string;
      items: Array<{ product_id: string; unit_value: number }>;
    },
  ) {
    const { data } = await http.post<SupplyOrder>('/api/admin/supply-orders', payload, {
      headers: authHeader(token),
    });
    return data;
  },

  async getAdminSupplyOrders(token: string, supplierUserId?: string) {
    const query = supplierUserId
      ? `?supplier_user_id=${encodeURIComponent(supplierUserId)}`
      : '';
    const { data } = await http.get<SupplyOrder[]>(`/api/admin/supply-orders${query}`, {
      headers: authHeader(token),
    });
    return data;
  },

  async updateAdminSupplyOrderStatus(
    token: string,
    id: string,
    payload: { status: string; notes?: string; expected_delivery_at?: string },
  ) {
    const { data } = await http.post<SupplyOrder>(
      `/api/admin/supply-orders/${id}/status`,
      payload,
      { headers: authHeader(token) },
    );
    return data;
  },

  async getSupplierProducts(token: string) {
    const { data } = await http.get<Product[]>('/api/supplier/products', {
      headers: authHeader(token),
    });
    return data;
  },

  async createSupplierProduct(
    token: string,
    payload: {
      name: string;
      description: string;
      category: string;
      price: number;
      inventory: number;
      unit: string;
      unit_value: number;
      image?: File | null;
    },
  ) {
    const fd = new FormData();
    Object.entries(payload).forEach(([k, v]) => {
      if (v === undefined || v === null) return;
      if (k === 'image' && v instanceof File) {
        fd.append('image', v);
      } else {
        fd.append(k, String(v));
      }
    });

    const { data } = await http.post<Product>('/api/supplier/products', fd, {
      headers: authHeader(token),
    });
    return data;
  },

  async deleteSupplierProduct(token: string, productId: string) {
    await http.delete(`/api/supplier/products/${productId}`, {
      headers: authHeader(token),
    });
  },

  async updateSupplierProduct(
    token: string,
    productId: string,
    payload: {
      name: string;
      description: string;
      category: string;
      price: number;
      inventory: number;
      unit: string;
      unit_value: number;
      image?: File | null;
    },
  ) {
    const fd = new FormData();
    Object.entries(payload).forEach(([k, v]) => {
      if (v === undefined || v === null) return;
      if (k === 'image' && v instanceof File) {
        fd.append('image', v);
      } else {
        fd.append(k, String(v));
      }
    });
    const { data } = await http.put<Product>(`/api/supplier/products/${productId}`, fd, {
      headers: authHeader(token),
    });
    return data;
  },

  async getSupplierSupplyOrders(token: string) {
    const { data } = await http.get<SupplyOrder[]>('/api/supplier/supply-orders', {
      headers: authHeader(token),
    });
    return data;
  },

  async updateSupplierSupplyOrderStatus(
    token: string,
    id: string,
    payload: { status: string; notes: string; expected_delivery_at?: string },
  ) {
    const { data } = await http.post<SupplyOrder>(
      `/api/supplier/supply-orders/${id}/status`,
      payload,
      { headers: authHeader(token) },
    );
    return data;
  },

  async getUnreadNotifications(token: string) {
    const { data } = await http.get<NotificationPayload>('/api/notifications/unread', {
      headers: authHeader(token),
    });
    return data;
  },

  async markNotificationsRead(token: string) {
    await http.post('/api/notifications/read-all', {}, { headers: authHeader(token) });
  },

  async importAdminCatalogExcel(
    token: string,
    payload: {
      file: File;
      source_label?: string;
      sheet_name?: string;
      assign_supplier_strategy?: 'none' | 'round_robin';
      sync_missing?: boolean;
      only_active?: boolean;
      dry_run?: boolean;
    },
  ) {
    const fd = new FormData();
    fd.append('file', payload.file);
    if (payload.source_label) fd.append('source_label', payload.source_label);
    if (payload.sheet_name) fd.append('sheet_name', payload.sheet_name);
    if (payload.assign_supplier_strategy) fd.append('assign_supplier_strategy', payload.assign_supplier_strategy);
    if (typeof payload.sync_missing === 'boolean') fd.append('sync_missing', String(payload.sync_missing));
    if (typeof payload.only_active === 'boolean') fd.append('only_active', String(payload.only_active));
    if (typeof payload.dry_run === 'boolean') fd.append('dry_run', String(payload.dry_run));
    const { data } = await http.post<CatalogImportSummary>('/api/admin/catalog/import-excel', fd, {
      headers: authHeader(token),
      timeout: 120000,
    });
    return data;
  },

  async uploadAdminProductsExcel(
    token: string,
    payload: {
      file: File;
      source_label?: string;
      sheet_name?: string;
      sync_missing?: boolean;
      dry_run?: boolean;
    },
  ) {
    const fd = new FormData();
    fd.append('file', payload.file);
    if (payload.source_label) fd.append('source_label', payload.source_label);
    if (payload.sheet_name) fd.append('sheet_name', payload.sheet_name);
    if (typeof payload.sync_missing === 'boolean') fd.append('sync_missing', String(payload.sync_missing));
    if (typeof payload.dry_run === 'boolean') fd.append('dry_run', String(payload.dry_run));
    const { data } = await http.post<CatalogImportSummary>('/api/admin/catalog/upload-products-excel', fd, {
      headers: authHeader(token),
      timeout: 120000,
    });
    return data;
  },

  async exportAdminCatalogExcel(token: string) {
    const { data, headers } = await http.get<Blob>('/api/admin/catalog/export-excel', {
      headers: authHeader(token),
      responseType: 'blob',
      timeout: 120000,
    });
    const contentDisposition = String(headers['content-disposition'] || '');
    const match = contentDisposition.match(/filename=\"?([^\";]+)\"?/i);
    const filename = match?.[1] || 'catalog_export.xlsx';
    return { blob: data, filename };
  },
};

export function getApiError(error: unknown) {
  if (axios.isAxiosError(error)) {
    const detail = error.response?.data?.detail;
    if (typeof detail === 'string' && detail.trim()) return detail;
    if (Array.isArray(detail) && detail[0]?.msg) return String(detail[0].msg);
    const raw = String(error.message || '').toLowerCase();
    if (error.code === 'ECONNABORTED' || raw.includes('timeout')) {
      return 'Server took too long to respond. Please try again.';
    }
    if (raw.includes('network error')) {
      return 'Unable to connect to server. Please check backend URL/network.';
    }
    return error.message;
  }
  return 'Something went wrong';
}
